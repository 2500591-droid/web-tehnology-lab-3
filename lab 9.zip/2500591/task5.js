const http = require('http');

const server = http.createServer((req, res) => {
    if (req.url === '/api') {
        const student = {
            name: "Sidra",
            course: "ADCS"
        };
        res.writeHead(200, { 'Content-Type': 'application/json' });
        res.end(JSON.stringify(student));
    } else {
        res.write("Welcome to Node.js API Server");
        res.end();
    }
});

server.listen(3210, () => {
    console.log("Server running at http://localhost:3210");
});