const fs = require('fs');

fs.writeFileSync('student.txt', 'Name: sidra\nCourse: ADSCS');

const data = fs.readFileSync('student.txt', 'utf8');
console.log(data);