console.log("Name: Siddrah");
console.log("Course: ADCS");
console.log("University: AIR University");