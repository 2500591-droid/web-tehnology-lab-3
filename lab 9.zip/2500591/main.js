const calc = require('./calc');

console.log(calc.sub(10, 5));
console.log(calc.mul(4, 3));