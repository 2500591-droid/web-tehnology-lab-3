const http = require('http');

const server = http.createServer((req, res) => {

if (req.url === '/home') {
res.write("Welcome to Home Page");
}
else if (req.url === '/about') {
res.write("Welcome to About Page");
}
else {
res.write("Page Not Found");
}

res.end();
});

server.listen(3020, () => {
console.log("Server running on port 3020");
});