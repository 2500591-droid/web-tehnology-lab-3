// Task 1: Interface and Class
var EmployeeClass = /** @class */ (function () {
    function EmployeeClass(id, name, salary) {
        this.id = id;
        this.name = name;
        this.salary = salary;
    }
    EmployeeClass.prototype.displayInfo = function () {
        console.log("Employee ID:", this.id);
        console.log("Employee Name:", this.name);
        console.log("Employee Salary:", this.salary);
    };
    return EmployeeClass;
}());
var emp1 = new EmployeeClass(1, "Siddrah", 50000);
emp1.displayInfo();
