var person = {};
person.name = "siddrah";
person.age = 21;
console.log("Person Name:", person.name);
console.log("Person Age:", person.age);
