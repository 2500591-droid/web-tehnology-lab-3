interface Person {
    name: string;
    age: number;
}

let person = {} as Person;

person.name = "siddrah";
person.age = 21;

console.log("Person Name:", person.name);
console.log("Person Age:", person.age);