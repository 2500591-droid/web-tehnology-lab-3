var rectangleArea = function (length, width) {
    return length * width;
};
var area = rectangleArea(10, 5);
console.log("Rectangle Area:", area);
