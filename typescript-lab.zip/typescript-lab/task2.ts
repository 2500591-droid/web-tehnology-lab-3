

let rectangleArea = (length: number, width: number): number => {
    return length * width;
};

let area = rectangleArea(10, 5);

console.log("Rectangle Area:", area);